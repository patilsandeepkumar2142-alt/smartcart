Put mysql-connector-j-9.4.0.jar in this folder before compiling the Java code.
