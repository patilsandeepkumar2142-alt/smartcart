CREATE DATABASE IF NOT EXISTS smartcart;
USE smartcart;

CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    role VARCHAR(20) DEFAULT 'CUSTOMER'
);

CREATE TABLE categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL
);

CREATE TABLE products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(150) NOT NULL,
    category_id INT,
    description VARCHAR(500),
    price DECIMAL(10,2) NOT NULL,
    stock INT DEFAULT 0,
    rating DECIMAL(2,1) DEFAULT 0,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

CREATE TABLE cart (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    product_id INT,
    quantity INT DEFAULT 1,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE wishlist (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    product_id INT,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    total_amount DECIMAL(10,2),
    status VARCHAR(50) DEFAULT 'PLACED',
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE order_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    product_id INT,
    quantity INT,
    price DECIMAL(10,2),
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE reviews (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    product_id INT,
    rating INT,
    comment VARCHAR(500),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

INSERT INTO categories(name) VALUES
('Electronics'),('Fashion'),('Books'),('Home & Kitchen'),('Sports');

INSERT INTO products(name,category_id,description,price,stock,rating) VALUES
('Wireless Headphones',1,'Bluetooth wireless headphones',2499,20,4.3),
('Smart Watch',1,'Fitness tracking smart watch',3499,15,4.2),
('Bluetooth Speaker',1,'Portable Bluetooth speaker',1799,18,4.2),
('Laptop Backpack',4,'Water resistant laptop backpack',1299,30,4.4),
('Running Shoes',5,'Comfortable running shoes',2999,25,4.5),
('Java Programming Book',3,'Complete Java programming guide',899,50,4.6),
('T-Shirt',2,'Cotton casual T-shirt',699,40,4.1),
('Mechanical Keyboard',1,'RGB mechanical keyboard',2999,12,4.4);

INSERT INTO users(name,email,password,role)
VALUES ('Admin','admin@smartcart.com','admin123','ADMIN');
