import java.sql.*;

public class BudgetAssistant {
    public static void findProducts(double budget, String category, String requirement) {
        String sql = "SELECT p.name,p.price,p.rating FROM products p " +
                     "JOIN categories c ON p.category_id=c.id " +
                     "WHERE p.price <= ? AND LOWER(c.name) LIKE LOWER(?) " +
                     "AND LOWER(p.name) LIKE LOWER(?) ORDER BY p.rating DESC";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDouble(1, budget);
            ps.setString(2, "%" + category + "%");
            ps.setString(3, "%" + requirement + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                System.out.println(rs.getString("name") + " | ₹" +
                    rs.getDouble("price") + " | Rating: " + rs.getDouble("rating"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
