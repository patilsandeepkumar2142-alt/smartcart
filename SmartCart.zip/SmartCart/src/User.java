import java.sql.*;

public class User {
    public static boolean register(String name, String email, String password) {
        String sql = "INSERT INTO users(name,email,password,role) VALUES(?,?,?,'CUSTOMER')";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, password);
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
