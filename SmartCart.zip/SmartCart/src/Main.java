public class Main {
    public static void main(String[] args) {
        if (DatabaseConnection.getConnection() != null) {
            System.out.println("SMARTCART BACKEND STARTED");
            System.out.println("Database Connected Successfully!");
        }
    }
}
