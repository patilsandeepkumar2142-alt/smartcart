import java.sql.*;

public class Product {
    public static void showProducts() {
        String sql = "SELECT p.id,p.name,c.name category,p.price,p.stock,p.rating " +
                     "FROM products p JOIN categories c ON p.category_id=c.id";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                System.out.println(rs.getInt("id") + " | " +
                    rs.getString("name") + " | ₹" + rs.getDouble("price") +
                    " | Stock: " + rs.getInt("stock") +
                    " | Rating: " + rs.getDouble("rating"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
