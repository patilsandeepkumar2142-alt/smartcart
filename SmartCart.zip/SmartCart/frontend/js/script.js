const products=[
{name:"Wireless Headphones",category:"Electronics",price:2499,rating:4.3},
{name:"Smart Watch",category:"Electronics",price:3499,rating:4.2},
{name:"Bluetooth Speaker",category:"Electronics",price:1799,rating:4.2},
{name:"Java Programming Book",category:"Books",price:899,rating:4.6},
{name:"Running Shoes",category:"Sports",price:2999,rating:4.5},
{name:"T-Shirt",category:"Fashion",price:699,rating:4.1}
];
function findProducts(){
 const budget=Number(document.getElementById("budget").value);
 const category=document.getElementById("category").value;
 const req=document.getElementById("requirement").value.toLowerCase();
 const result=products.filter(p=>p.price<=budget&&p.category===category&&(!req||p.name.toLowerCase().includes(req)));
 let html="<h2>Recommended Products</h2>";
 if(!result.length) html+="<p>No suitable products found within your budget.</p>";
 else result.forEach(p=>html+=`<div class="product"><h3>${p.name}</h3><p>₹${p.price}</p><p>⭐ ${p.rating}</p><button>Add to Cart</button></div>`);
 document.getElementById("result").innerHTML=html;
}